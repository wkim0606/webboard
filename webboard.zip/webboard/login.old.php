<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>로그인</title>
</head>
<body>
<h2>로그인</h2>

<form method="post" action="login_process.php">
    아이디: <input type="text" name="id" required><br><br>
    비밀번호: <input type="password" name="passwd" required><br><br>
    <button type="submit">로그인</button>
</form>

</body>
</html>

